

# STRUCTURE  DIAGRAMS
 ### High level design
  usecase diagram
![IMG](https://user-images.githubusercontent.com/66019753/109776906-1c959300-7c29-11eb-8a4b-e8c1bef0bb79.png)
## class diagram
![IMG](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0f8Aw-wz8JFlZfmM7YK4CWzJKvwHbN2T65w&usqp=CAU)


# BEHAVIOUR DIAGRAMS
 ### 1.Low level desigm
 state diagram
 ![IMG](https://i.pinimg.com/736x/c0/19/21/c019215ca831c0b0b75bdc2775e8e054--control-flow-uni.jpg)
 
 ## sequence diagram
 ![IMG](https://i.pinimg.com/originals/b4/42/2b/b4422bfdc81f24bbdf3b142b87ad4269.jpg)
