# Design

## High Level Design 
## * Architecture Design
![Architecture](https://github.com/goutami8989/Stepin_Movie-Ticket-Booking-System/blob/main/2_Architecture/highlevel.png)

## * Usecase Diagram
![UsecaseDiagram](https://github.com/goutami8989/Stepin_Movie-Ticket-Booking-System/blob/main/2_Architecture/Usecasehdl.png)

## Low Level Design 
## * Level0
![Level0](https://github.com/goutami8989/Stepin_Movie-Ticket-Booking-System/blob/main/2_Architecture/Level0.png)

## * Level1
![Level1](https://github.com/goutami8989/Stepin_Movie-Ticket-Booking-System/blob/main/2_Architecture/Level1.png)
