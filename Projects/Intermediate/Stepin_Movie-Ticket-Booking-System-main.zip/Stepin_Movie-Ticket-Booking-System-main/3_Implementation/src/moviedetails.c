#include<stdio.h>

struct movie_details{
	char name[25];
	char phoneno[15];
	int seatnum;
	int id;
};

