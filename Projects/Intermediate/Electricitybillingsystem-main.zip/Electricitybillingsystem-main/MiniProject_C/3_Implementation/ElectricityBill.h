#ifndef __ElectricityBill_H__
#define __ElectricityBill_H__

void Urban();
void Rural();

#endif  