# Structure Diagrams

## Low Level Structural Diagram

![Low_structure](https://user-images.githubusercontent.com/89764315/132291179-2931dbcb-4a4d-44f0-8d98-c68d1c45f87a.jpg)


## High Level Structural Diagram

![High_structure](https://user-images.githubusercontent.com/89764315/132291193-6557aade-1286-497d-b167-b3c95235d5eb.jpg)

