# Behavior Diagrams

## Low Level Behavior Diagram

![Low_Behavioural](https://user-images.githubusercontent.com/89764315/132293846-a5fdd1cd-0521-41f1-a13c-04fae582c81c.jpg)

## High Level Behavior Diagram

![HighBehavioural](https://user-images.githubusercontent.com/89764315/132295873-1d991f3d-be00-4278-8a0e-1ac8587dda9f.jpg)

