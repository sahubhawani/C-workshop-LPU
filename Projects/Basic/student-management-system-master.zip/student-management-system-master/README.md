# student-management-system

Student Management System written in C programming language. Daffodil International University , Spring 2017 m Data Structure lab Project . <br> 
<h1>Student Management System in C</h1>
<p>Simple project in c to manage student. You can add student, modify theme, delete theme. There is a different option to view all student and view student individually. 
</p>
<h2>Some screnshot.</h2>

![Front Page](http://i.imgur.com/3L7WEOx.jpg)
<br>
This is the front page of the program. 
<br>
![Main Page](http://i.imgur.com/mraVXvr.jpg)
<br>
It is the main page. Show all the option you can do with it. 
<br>
![Add Student Page](http://i.imgur.com/othYdgj.jpg)
<br>
Add Student page. You can store name, roll, department, sgpa and the cgpa will be calculated automatically. 
<br>
