# Calendar-in-C
This is a basic calendar program created using simple c program, using this program you can navigate year or month using the arrow key of your keyboard.

 # Screen Shot

  ![Sample Portfolio](https://github.com/Rocktim53/GUI-Calendar-in-C/blob/master/screenshot.png)